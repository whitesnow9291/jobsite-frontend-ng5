import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-minimizer',
  templateUrl: './app-sidebar-minimizer.component.html'
})
export class AppSidebarMinimizerComponent { }
